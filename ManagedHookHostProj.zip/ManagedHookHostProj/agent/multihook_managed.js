'use strict';

/*
  ============================================================
  Managed Resolver + Tracer (Frida 17+) for .NET Framework CLR v4
  Using helper DLL (cdecl) with:
    - ResolveMethod / ResolveMethodByToken
    - DescribeObjectUtf16 / FreeUtf16
    - ReadInt32 / WriteInt32
    - GetManagedStackTraceUtf16
    - ClearLastError / GetLastErrorUtf16

  Hooks:
   - SmdLogon.Process(bool)
   - SmdLogon.IsValidLogonCredentials(ref eLogonResults, bool)
   - StepCredentials.ValidateStep()
   - SmdLogon.IsValidClientLogonCredentials(ref eLogonResults, bool)
   - SmdLogon.IsValidUserName()
   - SmdLogon.GetLogMessageForLogonResult(eLogonResults)

  Notes:
   - Works x86 + x64 (decoder differs by arch).
   - Read-only tracing.
*/

const CONFIG = {
  helperDllPath: "C:\\Users\\Saber\\Desktop\\Hook_Tooling\\ManagedHookHostProj.dll",
  RESOLVE_DELAY_MS: 0,
  ENABLE_RETRY: true,
  RETRY_EVERY_MS: 1000,
  MAX_JUMP_HOPS: 16,

  // Prints managed stack trace from inside onEnter/onLeave (can be noisy).
  LOG_MANAGED_STACK_ON_ENTER: false,
  LOG_MANAGED_STACK_ON_LEAVE: false,

  // Native stack trace using DebugSymbol. Helpful but often addressy without symbols.
  LOG_NATIVE_STACK: false,
};

const ELOGON = {
  0: "None",
  1: "Success",
  2: "Canceled",
  3: "Offline",
  4: "InvalidUrl",
  5: "InvalidLocationCode",
  6: "InvalidCorpCode",
  7: "InvalidCredentials",
  8: "InvalidProxyCredentials",
  9: "InvalidReducedDataParameters",
  10: "LocationIsRunning",
  11: "LocationDisabled",
  12: "SitesRunningError",
  13: "WebServiceValidationError",
  14: "MutlipleInstancesOfSameSite",
  15: "UserAccessRestrictedByTime",
  16: "UserAcesssRestrictedAccountLocked",
  17: "LiveUpdateRequired",
  18: "NoProgramDefaults",
  19: "MultipleCorpCodes",
  20: "TransactionServerOffline",
  21: "IPRestricted",
  22: "SingleSignOnRedirect",
  23: "SsoEmployeeRecordNotFound",
  24: "SsoTokenValidationError",
  25: "SingleSignOn2024Redirect",
  27: "SingleSignOn2024Registration",
  28: "SSONotEnabledForCorp",
  29: "CorpSSOEnabledButNotUser",
  30: "InvalidUserName",
  31: "BPermanentUser",
};

function enumName(map, v) {
  const k = (v | 0);
  return map.hasOwnProperty(k) ? `${k}(${map[k]})` : `${k}`;
}

function allocW(s) {
  return (s === null || s === undefined) ? ptr(0) : Memory.allocUtf16String(s);
}

function modNameForAddress(p) {
  const m = Process.findModuleByAddress(p);
  return m ? `${m.name}+0x${p.sub(m.base)}` : "<no module>";
}

function rangeFor(p) {
  try { return Process.findRangeByAddress(p); } catch (_) { return null; }
}

function isReadable(p) {
  const r = rangeFor(p);
  return r !== null && r.protection.includes('r');
}

function isExecutable(p) {
  const r = rangeFor(p);
  return r !== null && r.protection.includes('x');
}

function dumpRange(label, p) {
  const r = rangeFor(p);
  if (!r) {
    console.log(`[!] ${label}: ${p} -> <no range>`);
    return;
  }
  const end = r.base.add(r.size);
  console.log(
    `[+] ${label}: ${p} -> ${r.base}..${end} prot=${r.protection} file=${r.file ? r.file.path : "<anon>"}`
  );
}

function logNativeStackTrace(context) {
  try {
    console.log(
      "[*] Native stack trace:\n" +
      Thread.backtrace(context, Backtracer.FUZZY)
        .map(DebugSymbol.fromAddress)
        .join("\n")
    );
  } catch (err) {
    console.log(`[!] Failed to log native stack: ${err.message}`);
  }
}

/*
  Follow common prestub/thunk patterns to reach actual JIT code
*/
function followJumps(p, maxHops = CONFIG.MAX_JUMP_HOPS) {
  let cur = ptr(p);

  for (let i = 0; i < maxHops; i++) {
    const b0 = cur.readU8();

    // JMP rel32: E9 xx xx xx xx
    if (b0 === 0xE9) {
      const rel = cur.add(1).readS32();
      const next = cur.add(5).add(rel);
      console.log(`[+] hop${i}: jmp rel32 ${cur} -> ${next}`);
      cur = next;
      continue;
    }

    // JMP rel8: EB xx
    if (b0 === 0xEB) {
      const rel8 = cur.add(1).readS8();
      const next = cur.add(2).add(rel8);
      console.log(`[+] hop${i}: jmp rel8  ${cur} -> ${next}`);
      cur = next;
      continue;
    }

    // JMP [mem]: FF 25 disp32  (x86 absolute / x64 RIP-relative)
    if (b0 === 0xFF && cur.add(1).readU8() === 0x25) {
      const disp = cur.add(2).readS32();
      if (Process.pointerSize === 8) {
        const slot = cur.add(6).add(disp);
        const next = slot.readPointer();
        console.log(`[+] hop${i}: jmp [rip+disp] ${cur} -> ${next} (slot=${slot})`);
        cur = next;
        continue;
      } else {
        const slot = ptr(cur.add(2).readU32());
        const next = slot.readPointer();
        console.log(`[+] hop${i}: jmp [abs] ${cur} -> ${next} (slot=${slot})`);
        cur = next;
        continue;
      }
    }

    // x64: mov rax, imm64; jmp rax  (48 B8 ... FF E0)
    if (Process.pointerSize === 8 &&
        b0 === 0x48 && cur.add(1).readU8() === 0xB8 &&
        cur.add(10).readU8() === 0xFF && cur.add(11).readU8() === 0xE0) {
      const imm = cur.add(2).readU64();
      const next = ptr(imm);
      console.log(`[+] hop${i}: mov rax; jmp rax ${cur} -> ${next}`);
      cur = next;
      continue;
    }

    break;
  }

  return cur;
}

// ============================================================
// Load helper + bind exports
// ============================================================

console.log(`[+] arch=${Process.arch} ptrSize=${Process.pointerSize}`);
console.log(`[+] Loading helper: ${CONFIG.helperDllPath}`);

const helper = Module.load(CONFIG.helperDllPath);

function mustExport(name) {
  const e = helper.findExportByName(name);
  if (!e) throw new Error(`Missing export: ${name}`);
  console.log(`[+] export ${name} @ ${e}`);
  return e;
}

const ResolveMethod = new NativeFunction(mustExport("ResolveMethod"), "pointer",
  ["pointer","pointer","pointer","pointer"]);

const DescribeObjectUtf16 = new NativeFunction(mustExport("DescribeObjectUtf16"), "pointer",
  ["pointer"]);

const FreeUtf16 = new NativeFunction(mustExport("FreeUtf16"), "void",
  ["pointer"]);

const ReadInt32 = new NativeFunction(mustExport("ReadInt32"), "int",
  ["pointer"]);

const GetManagedStackTraceUtf16 = new NativeFunction(mustExport("GetManagedStackTraceUtf16"), "pointer",
  []);

const ClearLastError = new NativeFunction(mustExport("ClearLastError"), "void",
  []);

const GetLastErrorUtf16 = new NativeFunction(mustExport("GetLastErrorUtf16"), "pointer",
  []);

// ============================================================
// Helper string utilities
// ============================================================

function readAndFreeUtf16(p) {
  if (p.isNull()) return null;
  let s = null;
  try { s = p.readUtf16String(); }
  catch (e) { s = `<utf16 read failed: ${e}>`; }
  try { FreeUtf16(p); } catch (_) {}
  return s;
}

function helperLastError() {
  try {
    const p = GetLastErrorUtf16();
    const s = readAndFreeUtf16(p);
    return s || "";
  } catch (_) {
    return "";
  }
}

function managedStackNow() {
  try {
    const p = GetManagedStackTraceUtf16();
    const s = readAndFreeUtf16(p);
    return s || "<no managed stack>";
  } catch (e) {
    return `<managed stack failed: ${e}>`;
  }
}

function describeManaged(objRef) {
  if (objRef.isNull()) return "<null>";
  try {
    const p = DescribeObjectUtf16(objRef);
    const s = readAndFreeUtf16(p);
    return s || "<DescribeObjectUtf16 returned empty>";
  } catch (e) {
    return `<DescribeObjectUtf16 failed: ${e}>`;
  }
}

// ============================================================
// Targets
// ============================================================

const HOOK_TARGETS = [
  {
    name: "SmdLogon.Process(bool)",
    asm: "C:\\Program Files (x86)\\SiteLink Web Edition\\Bin\\SLNet.SmdLogin.dll",
    type: "SLNet.SmdLogin.SmdLogon",
    method: "Process",
    sig: "System.Boolean",
    kind: "process_bool",
    ret: "enum_i32",
  },
  {
    name: "SmdLogon.IsValidLogonCredentials(ref eLogonResults, bool)",
    asm: "C:\\Program Files (x86)\\SiteLink Web Edition\\Bin\\SLNet.SmdLogin.dll",
    type: "SLNet.SmdLogin.SmdLogon",
    method: "IsValidLogonCredentials",
    sig: "SLNet.Common.eLogonResults&|System.Boolean",
    kind: "ref_enum_bool",
    ret: "bool",
  },
  {
    name: "StepCredentials.ValidateStep()",
    asm: "C:\\Program Files (x86)\\SiteLink Web Edition\\Bin\\SLNet.SmdLogin.dll",
    type: "SLNet.SmdLogin.StepCredentials",
    method: "ValidateStep",
    sig: "",
    kind: "noargs",
    ret: "unknown",
  },
  {
    name: "SmdLogon.IsValidClientLogonCredentials(ref eLogonResults, bool)",
    asm: "C:\\Program Files (x86)\\SiteLink Web Edition\\Bin\\SLNet.SmdLogin.dll",
    type: "SLNet.SmdLogin.SmdLogon",
    method: "IsValidClientLogonCredentials",
    sig: "SLNet.Common.eLogonResults&|System.Boolean",
    kind: "ref_enum_bool",
    ret: "bool",
  },
  {
    name: "SmdLogon.IsValidUserName()",
    asm: "C:\\Program Files (x86)\\SiteLink Web Edition\\Bin\\SLNet.SmdLogin.dll",
    type: "SLNet.SmdLogin.SmdLogon",
    method: "IsValidUserName",
    sig: "",
    kind: "noargs",
    ret: "bool",
  },
  {
    name: "SmdLogon.GetLogMessageForLogonResult(eLogonResults)",
    asm: "C:\\Program Files (x86)\\SiteLink Web Edition\\Bin\\SLNet.SmdLogin.dll",
    type: "SLNet.SmdLogin.SmdLogon",
    method: "GetLogMessageForLogonResult",
    sig: "SLNet.Common.eLogonResults",
    kind: "enum_i32",
    ret: "string_objref",
  },
];

// ============================================================
// Arg/return decode
// ============================================================

function readBoolFrom(v) { return ((v | 0) & 1) ? 1 : 0; }

function decodeArgs(t, ctx) {
  if (Process.arch === "x64") {
    const thisPtr = ptr(ctx.rcx);

    if (t.kind === "process_bool") {
      return { thisPtr, b: readBoolFrom(ctx.rdx.toInt32()) };
    }

    if (t.kind === "ref_enum_bool") {
      const refPtr = ptr(ctx.rdx);
      const b = readBoolFrom(ctx.r8.toInt32());
      let refVal;
      try { refVal = refPtr.isNull() ? null : ReadInt32(refPtr); }
      catch (_) { refVal = "<unreadable>"; }
      return { thisPtr, refPtr, refVal, b };
    }

    if (t.kind === "enum_i32") {
      return { thisPtr, e: (ctx.rdx.toInt32() | 0) };
    }

    return { thisPtr };
  }

  // x86
  const thisPtr = ptr(ctx.ecx);
  const esp = ptr(ctx.esp);

  if (t.kind === "process_bool") {
    let b = 0;
    try { b = readBoolFrom(esp.add(4).readU32()); } catch (_) { b = "<unreadable>"; }
    return { thisPtr, b };
  }

  if (t.kind === "ref_enum_bool") {
    let refPtr = ptr(ctx.edx);
    try {
      if (refPtr.isNull() || !isReadable(refPtr)) {
        refPtr = esp.add(4).readPointer();
      }
    } catch (_) {}

    let b = 0;
    try { b = readBoolFrom(esp.add(8).readU32()); } catch (_) { b = "<unreadable>"; }

    let refVal = null;
    try { refVal = refPtr.isNull() ? null : ReadInt32(refPtr); } catch (_) { refVal = "<unreadable>"; }

    return { thisPtr, refPtr, refVal, b };
  }

  if (t.kind === "enum_i32") {
    let e = 0;
    try { e = esp.add(4).readS32(); } catch (_) {}
    return { thisPtr, e };
  }

  return { thisPtr };
}

function decodeRet(t, retval) {
  const mode = (t.ret || "").toLowerCase();

  if (mode === "bool") return (retval.toInt32() & 1) ? 1 : 0;
  if (mode === "enum_i32") return retval.toInt32() | 0;

  if (mode === "string_objref") {
    if (retval.isNull()) return "<null>";
    return describeManaged(retval);
  }

  return retval;
}

// ============================================================
// Resolve + attach
// ============================================================

function keyOf(t) { return `${t.asm}::${t.type}::${t.method}(${t.sig})`; }
const ATTACHED = new Map();

function resolveMethodPtr(t) {
  ClearLastError();
  const p = ResolveMethod(allocW(t.asm), allocW(t.type), allocW(t.method), allocW(t.sig || ""));
  if (p.isNull()) {
    const err = helperLastError();
    if (err) console.log(`[!] [${t.name}] helper last error: ${err}`);
  }
  return p;
}

function attachOne(t) {
  const key = keyOf(t);
  if (ATTACHED.has(key)) return true;

  const label = t.name;

  let entry = ptr(0);
  try {
    entry = resolveMethodPtr(t);
  } catch (e) {
    console.log(`[!] [${label}] ResolveMethod threw: ${e}`);
    return false;
  }

  console.log(`[+] [${label}] ResolveMethod -> ${entry} (${modNameForAddress(entry)})`);
  dumpRange(`[${label}] entry`, entry);

  if (entry.isNull() || !isReadable(entry)) {
    console.log(`[-] [${label}] invalid entry pointer (null/unmapped).`);
    return false;
  }

  let real = entry;
  try { real = followJumps(entry, CONFIG.MAX_JUMP_HOPS); }
  catch (e) {
    console.log(`[!] [${label}] followJumps failed: ${e}`);
    return false;
  }

  console.log(`[+] [${label}] hook addr -> ${real} (${modNameForAddress(real)})`);
  dumpRange(`[${label}] real`, real);

  if (!isExecutable(real)) {
    console.log(`[-] [${label}] resolved address not executable; refusing to attach.`);
    return false;
  }

  try {
    Interceptor.attach(real, {
      onEnter(args) {
        const ctx = this.context;

        if (CONFIG.LOG_NATIVE_STACK) logNativeStackTrace(ctx);
        if (CONFIG.LOG_MANAGED_STACK_ON_ENTER) {
          console.log(`[MANAGED STACK] [${label}]`);
          console.log(managedStackNow());
        }

        const d = decodeArgs(t, ctx);

        if (t.kind === "ref_enum_bool") {
          this._refPtr = d.refPtr;
          console.log(`[ENTER] [${label}] this=${d.thisPtr} ref=${d.refPtr} *ref=${d.refVal} bReauth=${d.b}`);
          return;
        }

        if (t.kind === "enum_i32") {
          console.log(`[ENTER] [${label}] this=${d.thisPtr} eLogonResult=${enumName(ELOGON, d.e)}`);
          return;
        }

        if (t.kind === "process_bool") {
          console.log(`[ENTER] [${label}] this=${d.thisPtr} bReauth=${d.b}`);
          return;
        }

        console.log(`[ENTER] [${label}] this=${d.thisPtr}`);
      },

      onLeave(retval) {
        if (CONFIG.LOG_MANAGED_STACK_ON_LEAVE) {
          console.log(`[MANAGED STACK] [${label}] (onLeave)`);
          console.log(managedStackNow());
        }

        const out = decodeRet(t, retval);

        if ((t.ret || "").toLowerCase() === "enum_i32") {
          console.log(`[LEAVE] [${label}] retval=${enumName(ELOGON, out)}`);
        } else {
          console.log(`[LEAVE] [${label}] retval=${JSON.stringify(out)}`);
        }

        if (t.kind === "ref_enum_bool") {
          try {
            const p = this._refPtr;
            if (p && !p.isNull()) {
              const finalRef = ReadInt32(p);
              console.log(`[LEAVE] [${label}] final *ref=${enumName(ELOGON, finalRef)}`);
            }
          } catch (_) {}
        }
      }
    });
  } catch (e) {
    console.log(`[!] [${label}] Interceptor.attach failed: ${e}`);
    return false;
  }

  ATTACHED.set(key, real);
  console.log(`[+] [${label}] Attached OK`);
  return true;
}

function attachAllOnce() {
  let ok = 0;
  for (const t of HOOK_TARGETS) if (attachOne(t)) ok++;
  console.log(`[+] Attach pass: ${ok}/${HOOK_TARGETS.length} attached`);
  return ok === HOOK_TARGETS.length;
}

// ============================================================
// Startup
// ============================================================

console.log(`[+] Waiting ${CONFIG.RESOLVE_DELAY_MS}ms before resolving/hooking...`);

setTimeout(() => {
  const done = attachAllOnce();

  if (!done && CONFIG.ENABLE_RETRY) {
    console.log(`[+] Some targets not ready; retrying every ${CONFIG.RETRY_EVERY_MS}ms...`);
    const timer = setInterval(() => {
      const all = attachAllOnce();
      if (all) {
        console.log(`[+] All targets attached. Stopping retry loop.`);
        clearInterval(timer);
      }
    }, CONFIG.RETRY_EVERY_MS);
  }
}, CONFIG.RESOLVE_DELAY_MS);